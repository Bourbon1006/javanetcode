package zuoye4;

import javax.net.ssl.*;
import java.io.*;
import java.security.KeyStore;

public class EchoSSLClient {
    public static void main(String[] args) throws Exception {
        // 加载TrustStore并初始化SSL上下文
        KeyStore trustStore = KeyStore.getInstance("JKS");
        trustStore.load(new FileInputStream("zuoye4/client.truststore"), "password".toCharArray());

        TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        trustManagerFactory.init(trustStore);

        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, trustManagerFactory.getTrustManagers(), null);

        // 创建SSLSocket并连接到服务器
        SSLSocketFactory ssf = sslContext.getSocketFactory();
        SSLSocket socket = (SSLSocket) ssf.createSocket("localhost", 8081);

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader console = new BufferedReader(new InputStreamReader(System.in))) {

            String userInput;
            while ((userInput = console.readLine()) != null) {
                writer.println(userInput);
                System.out.println("Server: " + reader.readLine());
                if ("bye".equalsIgnoreCase(userInput)) {
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            socket.close();
        }
    }
}
