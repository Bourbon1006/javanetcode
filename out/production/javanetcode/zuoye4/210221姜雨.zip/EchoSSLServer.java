package zuoye4;

import javax.net.ssl.*;
import java.io.*;
import java.security.KeyStore;

public class EchoSSLServer {
    public static void main(String[] args) throws Exception {
        // 加载KeyStore并初始化SSL上下文
        KeyStore keyStore = KeyStore.getInstance("JKS");
        keyStore.load(new FileInputStream("zuoye4/server.keystore"), "password".toCharArray());

        KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        keyManagerFactory.init(keyStore, "password".toCharArray());

        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(keyManagerFactory.getKeyManagers(), null, null);

        // 创建SSLServerSocket并开始监听
        SSLServerSocketFactory ssf = sslContext.getServerSocketFactory();
        SSLServerSocket sss = (SSLServerSocket) ssf.createServerSocket(8081);

        System.out.println("SSL Echo Server started");

        while (true) {
            SSLSocket socket = (SSLSocket) sss.accept();
            new Thread(new EchoHandler(socket)).start();
        }
    }
}

class EchoHandler implements Runnable {
    private SSLSocket socket;

    public EchoHandler(SSLSocket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter writer = new PrintWriter(socket.getOutputStream(), true)) {

            String line;
            while ((line = reader.readLine()) != null) {
                writer.println(line);
                if ("bye".equalsIgnoreCase(line)) {
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
